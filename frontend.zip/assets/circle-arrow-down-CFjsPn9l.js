import{G as o}from"./createLucideIcon-B1I6BdvF.js";import"./chunk-QMGIS6GS-suYYFPSk.js";import"./index-GZitOFEf.js";/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const r=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 8v8",key:"napkw2"}],["path",{d:"m8 12 4 4 4-4",key:"k98ssh"}]],a=o("circle-arrow-down",r);export{r as __iconNode,a as default};
