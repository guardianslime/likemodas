import{bb as e}from"./createLucideIcon-BKEtgAre.js";import"./chunk-QMGIS6GS-CgUBpFMi.js";import"./index-B9RKNTce.js";/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const t=[["path",{d:"M11 14h1v4",key:"fy54vd"}],["path",{d:"M16 2v4",key:"4m81vk"}],["path",{d:"M3 10h18",key:"8toen8"}],["path",{d:"M8 2v4",key:"1cmpym"}],["rect",{x:"3",y:"4",width:"18",height:"18",rx:"2",key:"12vinp"}]],p=e("calendar-1",t);export{t as __iconNode,p as default};
