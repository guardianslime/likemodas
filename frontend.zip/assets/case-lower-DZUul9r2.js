import{G as c}from"./createLucideIcon-B1I6BdvF.js";import"./chunk-QMGIS6GS-suYYFPSk.js";import"./index-GZitOFEf.js";/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const e=[["circle",{cx:"7",cy:"12",r:"3",key:"12clwm"}],["path",{d:"M10 9v6",key:"17i7lo"}],["circle",{cx:"17",cy:"12",r:"3",key:"gl7c2s"}],["path",{d:"M14 7v8",key:"dl84cr"}]],a=c("case-lower",e);export{e as __iconNode,a as default};
