import{g as e}from"./chunk-BCmksqYJ.js";import{b as t}from"./react-CL9BJmZ0.js";import"./react-dom-D45cqs1e.js";import{E as n}from"./chunk-C37GKA54-COkmQZhr.js";import"./jsx-runtime-BZD1MDMi.js";import{j as r,m as i,t as a}from"./state-CJqixETV.js";import"./react-is-H20Ms6j1.js";import{$ as o,F as s,Z as c,a6 as l,a7 as u,a8 as d,aj as f,ak as p}from"./esm-mYBQkOgA.js";import"./shim-CADXBchW.js";import{B as m,F as h,c as g,d as _,e as v,g as y,w as b}from"./stateful_components-CX1A8Evt.js";import"./classnames-ClCpBGdC.js";import"./createLucideIcon-BqL3X7IO.js";import"./prop-types-Chknog0g.js";import"./es6-CdKFmjR7.js";import{b as x,c as S,d as C,e as w,f as T,g as E,h as D,i as O,j as k}from"./one-dark-DRRGLCk7.js";var A=e(t());function j(){let{resolvedColorMode:e}=(0,A.useContext)(r);return{h1:({node:e,children:t,...n})=>a(p,{as:`h1`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`6`,...n},t),h2:({node:e,children:t,...n})=>a(p,{as:`h2`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`5`,...n},t),h3:({node:e,children:t,...n})=>a(p,{as:`h3`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`4`,...n},t),h4:({node:e,children:t,...n})=>a(p,{as:`h4`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`3`,...n},t),h5:({node:e,children:t,...n})=>a(p,{as:`h5`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`2`,...n},t),h6:({node:e,children:t,...n})=>a(p,{as:`h6`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`1`,...n},t),p:({node:e,children:t,...n})=>a(f,{as:`p`,css:{marginTop:`1em`,marginBottom:`1em`},...n},t),ul:({node:e,children:t,...n})=>a(`ul`,{css:{listStyleType:`disc`,marginTop:`1em`,marginBottom:`1em`,marginLeft:`1.5rem`,direction:`column`}},t),ol:({node:e,children:t,...n})=>a(`ol`,{css:{listStyleType:`decimal`,marginTop:`1em`,marginBottom:`1em`,marginLeft:`1.5rem`,direction:`column`}},t),li:({node:e,children:t,...n})=>a(`li`,{css:{marginTop:`0.5em`,marginBottom:`0.5em`}},t),a:({node:e,children:t,...n})=>a(s,{css:{"&:hover":{color:`var(--accent-8)`}},href:`#`,...n},t),code:({node:t,inline:n,className:r,children:i,...o})=>{let s=(r||``).match(/language-(?<lang>.*)/),l=s?s[1]:``;return n?a(c,{...o},i):a(C,{children:Array.isArray(i)?i.join(`
`):i,css:{marginTop:`1em`,marginBottom:`1em`},language:l,style:e===`light`?S:x,wrapLongLines:!0,...o})}}}function M(){let e=(0,A.useContext)(i.reflex___state____state__reflex_local_auth___local_auth____local_auth_state__likemodas___state____app_state);return a(A.Fragment,{},e.is_admin_rx_state_||e.is_vendedor_rx_state_||e.is_empleado_rx_state_?a(A.Fragment,{},a(d,{css:{width:`100%`,minHeight:`100vh`}},a(v,{}),a(o,{columns:{initial:`1`,lg:`5em 1fr`},css:{width:`100%`}},a(d,{css:{"@media screen and (min-width: 0)":{display:`none`},"@media screen and (min-width: 30em)":{display:`none`},"@media screen and (min-width: 48em)":{display:`block`}}}),a(d,{css:{width:`100%`,height:`100%`,"@media screen and (min-width: 0)":{paddingInlineStart:`1em`,paddingInlineEnd:`1em`},"@media screen and (min-width: 30em)":{paddingInlineStart:`2em`,paddingInlineEnd:`2em`},paddingTop:`2em`,paddingBottom:`2em`}},a(d,{css:{maxWidth:`800px`,margin:`auto`,paddingTop:`2em`,paddingBottom:`2em`}},a(k,{components:j(),rehypePlugins:[T,w],remarkPlugins:[O,D,E]},`
# Política de Cookies de LIKEMODAS

**Fecha de última actualización:** [17 de octubre de 2025]

Este sitio web, www.likemodas.com ("Plataforma"), utiliza cookies para mejorar tu experiencia de usuario.

### 1. ¿Qué son las Cookies?
Una cookie es un pequeño archivo de texto que un sitio web guarda en tu ordenador o dispositivo móvil cuando lo visitas.

### 2. ¿Qué Cookies Utilizamos?
En LIKEMODAS, utilizamos únicamente cookies **esenciales y técnicas**. Estas cookies son estrictamente necesarias para el funcionamiento de la Plataforma y no se pueden desactivar en nuestros sistemas. Incluyen:

* **Cookies de Sesión (\`session_id\`):** Esta cookie es fundamental para identificarte una vez que has iniciado sesión. Nos permite saber quién eres mientras navegas por las diferentes páginas, manteniendo tu cuenta segura y activa. Sin esta cookie, tendrías que iniciar sesión en cada página.
* **Cookies de Funcionalidad del Carrito:** Utilizamos el almacenamiento local de tu navegador (una tecnología similar a las cookies) para guardar los productos que añades a tu carrito de compras. Esto asegura que tus productos no se pierdan si cierras la pestaña y vuelves más tarde.

No utilizamos cookies de marketing, publicidad o análisis de terceros.

### 3. Cómo Gestionar las Cookies
Aunque no puedes desactivar nuestras cookies esenciales sin afectar el funcionamiento del sitio, puedes configurar tu navegador para que las bloquee o te avise sobre ellas. Consulta la sección de ayuda de tu navegador para saber cómo hacerlo. Ten en cuenta que si bloqueas estas cookies, partes del sitio como el inicio de sesión o el carrito de compras no funcionarán.

### 4. Contacto
Si tienes preguntas sobre nuestra Política de Cookies, contáctanos en: soporte@likemodas.com
`)))))):a(A.Fragment,{},a(d,{css:{width:`100%`}},a(A.Fragment,{},a(g,{}),a(h,{})),a(d,{css:{paddingTop:`6rem`,paddingInlineStart:`1em`,paddingInlineEnd:`1em`,paddingBottom:`1em`,width:`100%`}},a(d,{css:{maxWidth:`800px`,margin:`auto`,paddingTop:`2em`,paddingBottom:`2em`}},a(k,{components:j(),rehypePlugins:[T,w],remarkPlugins:[O,D,E]},`
# Política de Cookies de LIKEMODAS

**Fecha de última actualización:** [17 de octubre de 2025]

Este sitio web, www.likemodas.com ("Plataforma"), utiliza cookies para mejorar tu experiencia de usuario.

### 1. ¿Qué son las Cookies?
Una cookie es un pequeño archivo de texto que un sitio web guarda en tu ordenador o dispositivo móvil cuando lo visitas.

### 2. ¿Qué Cookies Utilizamos?
En LIKEMODAS, utilizamos únicamente cookies **esenciales y técnicas**. Estas cookies son estrictamente necesarias para el funcionamiento de la Plataforma y no se pueden desactivar en nuestros sistemas. Incluyen:

* **Cookies de Sesión (\`session_id\`):** Esta cookie es fundamental para identificarte una vez que has iniciado sesión. Nos permite saber quién eres mientras navegas por las diferentes páginas, manteniendo tu cuenta segura y activa. Sin esta cookie, tendrías que iniciar sesión en cada página.
* **Cookies de Funcionalidad del Carrito:** Utilizamos el almacenamiento local de tu navegador (una tecnología similar a las cookies) para guardar los productos que añades a tu carrito de compras. Esto asegura que tus productos no se pierdan si cierras la pestaña y vuelves más tarde.

No utilizamos cookies de marketing, publicidad o análisis de terceros.

### 3. Cómo Gestionar las Cookies
Aunque no puedes desactivar nuestras cookies esenciales sin afectar el funcionamiento del sitio, puedes configurar tu navegador para que las bloquee o te avise sobre ellas. Consulta la sección de ayuda de tu navegador para saber cómo hacerlo. Ten en cuenta que si bloqueas estas cookies, partes del sitio como el inicio de sesión o el carrito de compras no funcionarán.

### 4. Contacto
Si tienes preguntas sobre nuestra Política de Cookies, contáctanos en: soporte@likemodas.com
`))))))}function N(){let e=(0,A.useContext)(i.reflex___state____state);return a(A.Fragment,{},e.is_hydrated_rx_state_?a(M,{}):a(A.Fragment,{},a(u,{css:{display:`flex`,alignItems:`center`,justifyContent:`center`,height:`100vh`,width:`100%`,background:`var(--gray-2)`}},a(l,{size:`3`}))))}var P=n(function(){return a(A.Fragment,{},a(d,{},a(N,{}),a(b,{}),a(m,{}),a(_,{}),a(d,{css:{position:`fixed`,bottom:`1.5rem`,right:`1.5rem`,zIndex:`1000`}},a(y,{}))),a(`title`,{},`Política de Cookies`),a(`meta`,{content:`favicon.ico`,property:`og:image`}))});export{P as default};