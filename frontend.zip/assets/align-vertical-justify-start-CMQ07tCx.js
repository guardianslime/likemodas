import{M as t}from"./createLucideIcon-CVZX51G5.js";import"./chunk-QMGIS6GS-CgUBpFMi.js";import"./index-B9RKNTce.js";/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const i=[["rect",{width:"14",height:"6",x:"5",y:"16",rx:"2",key:"1i8z2d"}],["rect",{width:"10",height:"6",x:"7",y:"6",rx:"2",key:"13squh"}],["path",{d:"M2 2h20",key:"1ennik"}]],c=t("align-vertical-justify-start",i);export{i as __iconNode,c as default};
