import{L as c}from"./createLucideIcon-BaKMIaGk.js";import"./chunk-QMGIS6GS-CgUBpFMi.js";import"./index-B9RKNTce.js";/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const r=[["circle",{cx:"12",cy:"12",r:"6",key:"1vlfrh"}]],i=c("circle-small",r);export{r as __iconNode,i as default};
